extern void * xmalloc(
    long n);
extern void *xrealloc(
    void *ptr,
    long n);
#define xfree free
