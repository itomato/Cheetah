#include "stuff/bool.h"

extern char * guess_short_name(
    char *name,
    enum bool *is_framework,
    char **return_suffix);
