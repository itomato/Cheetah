/*
 * Copyright (c) 1999 Apple Computer, Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * Portions Copyright (c) 1999 Apple Computer, Inc.  All Rights
 * Reserved.  This file contains Original Code and/or Modifications of
 * Original Code as defined in and that are subject to the Apple Public
 * Source License Version 1.1 (the "License").  You may not use this file
 * except in compliance with the License.  Please obtain a copy of the
 * License at http://www.apple.com/publicsource and read it before using
 * this file.
 * 
 * The Original Code and all software distributed under the License are
 * distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON- INFRINGEMENT.  Please see the
 * License for the specific language governing rights and limitations
 * under the License.
 * 
 * @APPLE_LICENSE_HEADER_END@
 */
/*
 * Copyright (c) 1981, 1993, 1994
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *	This product includes software developed by the University of
 *	California, Berkeley and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE REGENTS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */


#include "curses.h"

/* Private. */
int	__echoit = 1;			/* If stty indicates ECHO. */
int	__pfast = 0;
int	__rawmode = 0;			/* If stty indicates RAW mode. */
int	__noqch = 0;			/* 
					 * If terminal doesn't have 
					 * insert/delete line capabilities 
					 * for quick change on refresh.
					 */
char	AM = 0, BS = 0, CA = 0, DA = 0, EO = 0, HC = 0, IN = 0,
	MI = 0, MS = 0, NC = 0, NS = 0, OS = 0, PC = 0, UL = 0,
	XB = 0, XN = 0, XT = 0, XS = 0, XX = 0;
char	*AL = NULL, *BC = NULL, *BT = NULL, *CD = NULL, *CE = NULL,
	*CL = NULL, *CM = NULL, *CR = NULL, *CS = NULL, *DC = NULL,
	*DL = NULL, *DM = NULL, *DO = NULL, *ED = NULL, *EI = NULL,
	*K0 = NULL, *K1 = NULL, *K2 = NULL, *K3 = NULL, *K4 = NULL,
	*K5 = NULL, *K6 = NULL, *K7 = NULL, *K8 = NULL, *K9 = NULL,
	*HO = NULL, *IC = NULL, *IM = NULL, *IP = NULL, *KD = NULL,
	*KE = NULL, *KH = NULL, *KL = NULL, *KR = NULL, *KS = NULL,
	*KU = NULL, *LL = NULL, *MA = NULL, *ND = NULL, *NL = NULL,
	*RC = NULL, *SC = NULL, *SE = NULL, *SF = NULL, *SO = NULL,
	*SR = NULL, *TA = NULL, *TE = NULL, *TI = NULL, *UC = NULL,
	*UE = NULL, *UP = NULL, *US = NULL, *VB = NULL, *VS = NULL,
	*VE = NULL, *al = NULL, *dl = NULL, *sf = NULL, *sr = NULL,
	*AL_PARM = NULL, *DL_PARM = NULL, *UP_PARM = NULL, *DOWN_PARM = NULL,
	*LEFT_PARM = NULL, *RIGHT_PARM = NULL;
/*
 * Public.
 *
 * XXX
 * UPPERCASE isn't used by libcurses, and is left for backward
 * compatibility only.
 */
WINDOW	*curscr = NULL;			/* Current screen. */
WINDOW	*stdscr = NULL;			/* Standard screen. */
int	 COLS = 0;			/* Columns on the screen. */
int	 LINES = 0;			/* Lines on the screen. */
int	 My_term = 0;			/* Use Def_term regardless. */
char	*Def_term = "unknown";		/* Default terminal type. */
char	 GT = 0;			/* Gtty indicates tabs. */
char	 NONL = 0;			/* Term can't hack LF doing a CR. */
char	 UPPERCASE = 0;			/* Terminal is uppercase only. */
