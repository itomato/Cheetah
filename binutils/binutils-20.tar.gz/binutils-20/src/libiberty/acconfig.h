/* Define if you have the sys_errlist variable.  */
#undef HAVE_SYS_ERRLIST

/* Define if you have the sys_nerr variable.  */
#undef HAVE_SYS_NERR

/* Define if you have the sys_siglist variable.  */
#undef HAVE_SYS_SIGLIST

/* Define if you have the strerror function.  */
#undef HAVE_STRERROR

/* Define if you want to use the memory mapped malloc package (mmalloc). */
#undef USE_MMALLOC
