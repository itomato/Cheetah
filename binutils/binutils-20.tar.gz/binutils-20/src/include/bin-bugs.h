#ifndef REPORT_BUGS_TO
#define REPORT_BUGS_TO	"bug-gnu-utils@gnu.org"
#endif
