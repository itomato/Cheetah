/* Version number of GNU diff.  */

#include <config.h>

char const diff_version_string[] = "2.7";
