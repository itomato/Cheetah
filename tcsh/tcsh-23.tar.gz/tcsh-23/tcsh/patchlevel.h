/* $Header: /cvs/Darwin/Commands/Other/tcsh/tcsh/patchlevel.h,v 1.1.1.1 1999/04/23 01:59:53 wsanchez Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 8
#define PATCHLEVEL 0
#define DATE "1998-10-02"

#endif /* _h_patchlevel */
