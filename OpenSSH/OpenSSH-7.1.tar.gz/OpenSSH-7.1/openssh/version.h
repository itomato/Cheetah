/* $OpenBSD: version.h,v 1.13 2000/10/16 09:38:45 djm Exp $ */

#define SSH_VERSION	"OpenSSH_2.3.0p1"
