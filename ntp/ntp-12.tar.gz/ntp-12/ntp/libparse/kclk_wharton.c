/*
 * /src/NTP/ntp-4/libparse/kclk_wharton.c,v 4.1 1999/02/28 15:50:08 kardel RELEASE_19990228_A
 *
 * $Created: Sun Feb 28 16:46:14 MET 1999 $
 *
 * Copyright (C) 1999 by Frank Kardel
 */
#define PARSESTREAM
#include "clk_wharton.c"
/*
 * kclk_wharton.c,v
 * Revision 4.1  1999/02/28 15:50:08  kardel
 * new clock input machine
 *
 */
