/*
 * /src/NTP/ntp-4/libparse/kclk_computime.c,v 4.2 1998/07/11 10:05:27 kardel RELEASE_19990228_A
 *
 * $Created: Sat Jun 13 09:58:27 1998 $
 *
 * Copyright (C) 1998 by Frank Kardel
 */
#define PARSESTREAM
#include "clk_computime.c"
/*
 * kclk_computime.c,v
 * Revision 4.2  1998/07/11 10:05:27  kardel
 * Release 4.0.73d reconcilation
 *
 * Revision 4.1  1998/06/13 12:09:27  kardel
 * hack to compile the source for kernel/user-land
 */
