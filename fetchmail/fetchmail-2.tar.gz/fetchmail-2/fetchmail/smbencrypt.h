void SMBencrypt(char *passwd, uint8 *c8, uint8 *p24);
void SMBNTencrypt(char *passwd, uint8 *c8, uint8 *p24);
