/* next-pdo.c: Functions for NeXT-pdo compiler running on alpha AXP*/

#include "alpha/alpha.c"

