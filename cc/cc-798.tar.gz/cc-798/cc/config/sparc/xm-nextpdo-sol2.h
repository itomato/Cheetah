#include "sparc/xm-sol2.h"

#ifndef USE_GAS
#define USE_GAS
#endif

#ifndef NEXT_OBJC_RUNTIME
#define NEXT_OBJC_RUNTIME
#endif

#ifndef NEXT_PDO
#define NEXT_PDO
#endif

#ifndef NEXT_FRAMEWORK
#define NEXT_FRAMEWORK
#endif
