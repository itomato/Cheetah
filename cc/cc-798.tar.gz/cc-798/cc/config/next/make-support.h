extern void v_make_support (int type, char *name, char *file, int line,
			    char *msg, va_list ap);
extern void   make_support (int type, char *name, char *file, int line,
			    char *msg, ...);
