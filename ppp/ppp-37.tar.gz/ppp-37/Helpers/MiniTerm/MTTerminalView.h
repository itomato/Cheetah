#import <Cocoa/Cocoa.h>

@interface MTTerminalView : NSTextView
{
}
@end
