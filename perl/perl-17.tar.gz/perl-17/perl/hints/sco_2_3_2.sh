yacc='/usr/bin/yacc -Sm25000'
libswanted=`echo " $libswanted "| sed 's/ x / /'`
