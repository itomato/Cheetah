/* Tips.h */

#define NTIPS ((int) (sizeof(gTipList) / sizeof(char *)))

void PrintTip(char *);
void PrintRandomTip(void);
void PrintAllTips(void);
