/* Cpp.h */

typedef struct CppSymbol {
	char *name;
	int symType;
	long l;
	char *s;
} CppSymbol;
