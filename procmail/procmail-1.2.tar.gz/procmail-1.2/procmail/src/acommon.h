/*$Id: acommon.h,v 1.1.1.1 1999/09/23 17:30:07 wsanchez Exp $*/

const char
 *hostname P((void));
char
 *ultoan P((unsigned long val,char*dest));
