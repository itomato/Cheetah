/*$Id: mcommon.h,v 1.1.1.1 1999/09/23 17:30:07 wsanchez Exp $*/

void
 qsignal P((const sig,void(*action)(void)));
