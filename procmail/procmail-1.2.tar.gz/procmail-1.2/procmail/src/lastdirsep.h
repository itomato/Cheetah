/*$Id: lastdirsep.h,v 1.1.1.1 1999/09/23 17:30:07 wsanchez Exp $*/

char
 *lastdirsep P((const char*filename));
