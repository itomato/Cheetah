#import <AppKit/NSView.h>

@interface ResponseMeter : NSView

- (void)displayFilled;

@end
