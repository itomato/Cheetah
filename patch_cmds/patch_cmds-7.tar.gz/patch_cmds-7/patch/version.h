/* Print the version number.  */

/* $Id: version.h,v 1.1.1.2 2000/05/06 22:44:56 wsanchez Exp $ */

void version PARAMS ((void));
