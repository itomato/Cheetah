#ifdef HAVE_CONFIG_H
# include <config.h>
#endif
#include "system.h"
#include "grep.h"
char const *matcher = "fgrep";
