#include "rs6000/xm-rs6000.h"

#undef USG
