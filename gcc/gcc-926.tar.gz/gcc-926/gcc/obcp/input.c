#include "../cp/input.c"
