// Implementation file for the -*- C++ -*- math functions header.
// This file is part of the GNU ANSI C++ Library.

#ifdef __GNUG__
#pragma implementation "cmath"
#endif
#include <cmath>
