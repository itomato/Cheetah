/* crypt.c (dummy version) -- do not perform encryption
 * Hardly worth copyrighting :-)
 */
#ifdef RCSID
static char rcsid[] = "$Id: crypt.c,v 1.1.1.1 1999/04/23 01:05:56 wsanchez Exp $";
#endif
