/* PACKAGE name */
#undef PACKAGE

/* Package VERSION number */
#undef VERSION

/* define if the math lib is to be loaded from a file. */
#undef BC_MATH_FILE

/* Define to use the readline library. */
#undef READLINE

/* Define to `size_t' if <sys/types.h> and <stddef.h> don't define.  */
#undef ptrdiff_t

