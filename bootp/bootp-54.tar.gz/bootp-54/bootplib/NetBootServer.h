
#define NETBOOT_DIRECTORY		"/Library/NetBoot"
#define NETBOOT_SHAREPOINT_PREFIX	"NetBootSP"
#define NETBOOT_SHAREPOINT_LINK		".sharepoint"

#define NETBOOT_GROUP			"netboot"
#define NETBOOT_USER_PREFIX		"netboot"

