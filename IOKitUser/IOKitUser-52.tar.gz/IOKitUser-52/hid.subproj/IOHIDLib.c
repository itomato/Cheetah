// Work around ProjectBuilderWO problem

#include <IOKit/hid/IOHIDLib.h>

__private_extern__
const char _IOKIT_HID_IOHIDLIB_C_subproj_workaround[] = "_IOKIT_HID_IOHIDLIB_C_";
