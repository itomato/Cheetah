#ifdef __cplusplus
extern "C" {
#endif

#include <IOKit/iokitmig_c.h>

#ifdef __cplusplus
}
#endif

