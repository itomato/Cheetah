#define __strtol strtoul
#define __strtol_t unsigned long int
#define __xstrtol xstrtoul
#include "xstrtol.c"
